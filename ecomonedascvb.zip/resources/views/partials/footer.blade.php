<footer style="position: absolute; bottom: 0; width: 100%; height: 60px; line-height: 60px; background-color: #80cbc4;}">
    <div class="container">
        <p> © Copyright 2018 - Christian Vargas - UTN </p>
    </div>
</footer>